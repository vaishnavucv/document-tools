# pdf-page-counter
python script for counting number of pages in a  pdf in bulk files
